package org.firstinspires.ftc.teamcode.tele;

import static org.firstinspires.ftc.teamcode.constants.robotConstants.autoEndH;
import static org.firstinspires.ftc.teamcode.constants.robotConstants.autoEndX;
import static org.firstinspires.ftc.teamcode.constants.robotConstants.autoEndY;
import static org.firstinspires.ftc.teamcode.subsystems.Shooter.targetVelocity;

import com.bylazar.configurables.annotations.Configurable;
import com.bylazar.telemetry.JoinedTelemetry;
import com.bylazar.telemetry.PanelsTelemetry;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathBuilder;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.subsystems.AutoAimSubsystem_MK2;
import org.firstinspires.ftc.teamcode.subsystems.FollowerSubsystem;
import org.firstinspires.ftc.teamcode.subsystems.Robot;

/**
 * ============================================================================
 * AA_TeleOp_Base —— 自瞄 TeleOp 基类（重构版）
 * ============================================================================
 *
 * <p>所有操作/瞄准逻辑集中在这里。子类只需提供 5 项信息：
 * <ol>
 *   <li>球门目标点坐标（{@link #getTargetX}/{@link #getTargetY}）</li>
 *   <li>里程计复位基准点（{@link #getRelocalizePose}）</li>
 *   <li>联盟名称（{@link #getAllianceName}）</li>
 *   <li>手柄功能分配（{@link #configureMapping}）</li>
 *   <li>一键自动跑打宏的目标位姿（{@link #getAutoShootPose}）</li>
 * </ol>
 *
 * <h3>手柄映射说明</h3>
 * 子类通过 {@link #configureMapping(GamepadRole)} 决定每个功能分配到哪个手柄：
 *
 * <pre>{@code
 *   // 单操作手：全部用 gamepad1
 *   m.chassis    = gamepad1;  // 底盘摇杆
 *   m.actions    = gamepad1;  // 扳机收球/吐球、RB喂球
 *   m.toggles    = gamepad1;  // LB飞轮开关、Y移动发射(跑打)
 *   m.trims      = gamepad1;  // 方向键距离/航向微调
 *   m.relocalize = gamepad1;  // Start 里程计复位
 *   m.autoShoot  = gamepad1;  // X 一键自动跑打宏(按住)
 *
 *   // 双操作手：1号手底盘+收球，2号手微调
 *   m.chassis    = gamepad1;
 *   m.actions    = gamepad1;
 *   m.toggles    = gamepad1;
 *   m.trims      = gamepad2;
 *   m.relocalize = gamepad1;
 *   m.autoShoot  = gamepad1;
 * }</pre>
 *
 * <h3>相对上一版更新的内容</h3>
 * <ol>
 *   <li><b>转塔改为全程自瞄</b>：不再受"总开关"控制，每帧无条件调用 autoAim.update()。
 *       {@code shooterOn}(左保险杠切换) 现在只管飞轮目标转速+挡球板开合，不影响转塔/浮板。
 *       之前加的 {@code autoAim.disable()} 调用已经从主循环里去掉(方法本身还留着，
 *       以后如果又想要"可以关闭自瞄"这个模式，随时可以拿来用)。</li>
 *   <li><b>新增一键自动跑打宏</b>：按住 X → 飞轮提前开启+Pedro Pathing接管底盘开去
 *       {@link #getAutoShootPose()}；摇杆一动立刻打断交还控制权；正常松开 X →
 *       交还底盘控制权，同时自动喂球开火 {@code AUTO_SHOOT_FEED_MS} 毫秒。
 *       ⚠️ 这里假设 Pedro Pathing 的 Pose 坐标系和 {@code robot.drivetrain.getPosition()}
 *       是同一套(参考 autoConstants.java 里 RED_FAR_START 的数值范围推断)，实测如果方向不对
 *       要检查这个假设。</li>
 * </ol>
 */
@Configurable
public abstract class AA_TeleOp_Base extends LinearOpMode {

    // ========================================================================
    // 手柄功能映射 —— 子类通过 configureMapping() 分配手柄
    // ========================================================================

    public static class GamepadRole {
        /** 底盘控制（左/右摇杆） */
        public Gamepad chassis;
        /** 收球/吐球/喂球（扳机 + RB） */
        public Gamepad actions;
        /** 模式切换（LB飞轮开关 / Y跑打） */
        public Gamepad toggles;
        /** 方向键微调（dpad 距离/航向） */
        public Gamepad trims;
        /** 里程计复位（Start） */
        public Gamepad relocalize;
        /** 一键自动跑打宏（X，按住） */
        public Gamepad autoShoot;
    }

    /**
     * 子类在此方法中把 gamepad1 / gamepad2 分配给各个功能。
     * <p>在 {@link #runOpMode()} 初始化阶段调用一次。
     */
    protected abstract void configureMapping(GamepadRole m);

    /** 当前实例的手柄映射（在 runOpMode 中初始化后有效）。 */
    protected GamepadRole mapping;

    // ========================================================================
    // @Configurable 可调参数
    // ========================================================================

    public static double drivePower              = 1.0;
    public static double yawCorrection           = 0.0;
    public static double velocityCorrection      = 0.0;
    public static double distanceCorrection      = 0.0;
    public static boolean shootOnTheMoveDefault  = true;
    public static boolean manualDistanceMode     = false;
    public static double manualDistance          = 60.0;
    public static double brakeStickThreshold     = 0.15;

    /** 宏松开按键后，自动喂球开火持续多久(毫秒)——按需调，具体多久能把球喂进去要实测。 */
    public static double AUTO_SHOOT_FEED_MS = 400.0;
    /** 摇杆推过这个幅度就判定"操作手要抢控制权"，宏立刻中断。 */
    public static double MACRO_INTERRUPT_STICK_THRESHOLD = 0.05;

    private static final double MAX_YAW_CORRECTION_DEG     = 15.0;
    private static final double MAX_DISTANCE_CORRECTION_IN = 24.0;

    // ========================================================================
    // 子系统
    // ========================================================================
    protected final Robot robot = new Robot();
    protected final AutoAimSubsystem_MK2 autoAim = new AutoAimSubsystem_MK2();
    protected FollowerSubsystem followerSub;   // 一键自动跑打宏用，Pedro Pathing
    protected JoinedTelemetry joinedTele;

    // ========================================================================
    // 运行时状态
    // ========================================================================
    private boolean shooterOn = false;
    private boolean shootOnTheMove;
    private boolean macroActive = false;     // 宏是否正在跑(按住X期间)
    private boolean firePending = false;     // 松开X之后，正在走"自动喂球开火"这一小段
    private final ElapsedTime loopTimer = new ElapsedTime();
    private final ElapsedTime fireTimer = new ElapsedTime();

    // ========================================================================
    // 子类必须提供的信息
    // ========================================================================

    protected abstract double getTargetX();
    protected abstract double getTargetY();
    protected abstract Pose2D getRelocalizePose();
    protected abstract String getAllianceName();

    /**
     * 一键自动跑打宏的目标位姿(Pedro Pathing坐标系：x/y英寸，heading弧度)。
     * 按住 {@code mapping.autoShoot} 对应的按键时，机器人会自动开到这个位姿。
     */
    protected abstract Pose getAutoShootPose();

    // ========================================================================
    // 主流程
    // ========================================================================
    @Override
    public void runOpMode() throws InterruptedException {
        // ---- 初始化 ----
        robot.init(hardwareMap);
        autoAim.init(hardwareMap);
        // Pedro Pathing的Follower，只在按住"一键自动跑打"宏的时候才会接管底盘
        followerSub = new FollowerSubsystem(hardwareMap, PanelsTelemetry.INSTANCE.getTelemetry());
        shootOnTheMove = shootOnTheMoveDefault;
        mapping = new GamepadRole();
        configureMapping(mapping);

        // 校验：所有映射必须非空
        validateMapping();

        resetToAutoEndPose();
        // 把Pedro自己的起始位姿也同步一下，跟PinPoint对齐
        // ⚠️ 这里假设Pedro的Pose坐标系和 robot.drivetrain.getPosition() 是同一套(根据
        // autoConstants.java里 RED_FAR_START 的数值范围推断)，如果实测发现按宏之后车往
        // 错误方向跑，先检查这里是不是需要额外做镜像/旋转
        {
            Pose2D startPose = robot.drivetrain.getPosition();
            followerSub.setStartingPose(new Pose(
                    startPose.getX(DistanceUnit.INCH),
                    startPose.getY(DistanceUnit.INCH),
                    startPose.getHeading(AngleUnit.RADIANS)
            ));
        }

        joinedTele = new JoinedTelemetry(telemetry, PanelsTelemetry.INSTANCE.getFtcTelemetry());
        joinedTele.addData("alliance", getAllianceName());
        joinedTele.addData("targetX", getTargetX());
        joinedTele.addData("targetY", getTargetY());
        joinedTele.addData("提示", "按 START 前请确认机器人已放置在正确起始位置");
        joinedTele.update();

        waitForStart();
        resetToAutoEndPose();
        loopTimer.reset();

        while (opModeIsActive()) {
            double loopMs = loopTimer.milliseconds();
            loopTimer.reset();

            // 1. 读取位姿（自瞄 + 自动跑打宏都要用，提前到最前面读一次）
            Pose2D current = robot.drivetrain.getPosition();
            double rx  = current.getX(DistanceUnit.INCH);
            double ry  = current.getY(DistanceUnit.INCH);
            double hdg = current.getHeading(AngleUnit.DEGREES);
            double vx  = robot.drivetrain.pinPoint.getVelX(DistanceUnit.INCH);
            double vy  = robot.drivetrain.pinPoint.getVelY(DistanceUnit.INCH);
            double omg = robot.drivetrain.pinPoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES);

            // 2. 一键自动跑打宏（按住=自动开去目标点，摇杆一动/松开就交还控制权）
            handleAutoShootMacro(rx, ry, hdg);

            // 3. 底盘：宏没在跑的时候才走手动摇杆，宏在跑的时候底盘归Pedro Follower管
            if (!macroActive) {
                robot.drivetrain.drive(mapping.chassis, drivePower);
            }

            // 4. 进球/吐球/喂球
            handleIntake();

            // 5. 模式切换
            handleToggles();

            // 6. 方向键微调
            handleTrims();

            // 7. 里程计复位
            handleFieldRelocalize();

            double mDist = Math.max(0.0, manualDistance + distanceCorrection);
            boolean braking = Math.hypot(mapping.chassis.left_stick_x,
                                         mapping.chassis.left_stick_y) < brakeStickThreshold;

            // ---- 转塔全程自瞄：不受任何开关影响，每帧都调用 update() ----
            // 左保险杠(shooterOn)现在只管飞轮转速+挡球板，不再影响转塔/浮板
            AutoAimSubsystem_MK2.SHOT_DIST_OFFSET = distanceCorrection;
            AutoAimSubsystem_MK2.TurretCommand cmd = autoAim.update(
                    rx, ry, vx, vy, hdg, omg,
                    getTargetX(), getTargetY(),
                    manualDistanceMode, mDist,
                    shootOnTheMove, braking, yawCorrection
            );

            if (shooterOn) {
                robot.intake.gateOpen();
                targetVelocity = cmd.targetRpm + velocityCorrection;
                robot.shooter.setShooterVelocity(targetVelocity);
            } else {
                robot.intake.gateClose();
                robot.shooter.shooterHold();
            }

            // 8. 遥测
            updateTelemetry(rx, ry, hdg, vx, vy, omg, cmd, loopMs);
        }

        autoAim.stop();
        robot.shooter.shooterStop();
        robot.intake.intakeStop();
    }

    // ========================================================================
    // 各处理函数
    // ========================================================================

    private void resetToAutoEndPose() {
        robot.drivetrain.pinPoint.setPosition(new Pose2D(
                DistanceUnit.INCH, autoEndY, 144.0 - autoEndX,
                AngleUnit.RADIANS, autoEndH - Math.PI / 2.0));
    }

    private void handleFieldRelocalize() {
        if (mapping.relocalize.startWasPressed()) {
            robot.drivetrain.pinPoint.setPosition(getRelocalizePose());
        }
    }

    /**
     * 进球/吐球/喂球。
     * <ul>
     *   <li>firePending(宏松开后自动开火中) → 强制喂球，忽略手柄输入，直到计时结束</li>
     *   <li>右扳机(>0.1) → 收球（不再影响总开关——总开关现在只归左保险杠管）</li>
     *   <li>左扳机(>0.1) → 吐球，功率=扳机行程</li>
     *   <li>右保险杠(按住) → 喂球给炮塔，功率动态</li>
     *   <li>都没按 → 停止</li>
     * </ul>
     */
    private void handleIntake() {
        if (firePending) {
            if (fireTimer.milliseconds() >= AUTO_SHOOT_FEED_MS) {
                firePending = false;
                robot.intake.intakeStop();
            } else {
                robot.intake.intakeIn(robot.shooter.calculateIntakePower());
            }
            return;
        }

        Gamepad g = mapping.actions;
        if (g.right_trigger > 0.1) {
            robot.intake.intakeIn();
        } else if (g.left_trigger > 0.1) {
            robot.intake.intakeOut(g.left_trigger);
        } else if (g.right_bumper) {
            robot.intake.intakeIn(robot.shooter.calculateIntakePower());
        } else {
            robot.intake.intakeStop();
        }
    }

    /** 边沿触发，按一次翻转。 */
    private void handleToggles() {
        Gamepad g = mapping.toggles;
        if (g.leftBumperWasPressed()) shooterOn     = !shooterOn;  // 飞轮转速+挡球板开关(转塔/浮板不受影响，全程自瞄)
        if (g.yWasPressed())          shootOnTheMove = !shootOnTheMove; // 跑打(移动发射预判)
    }

    /** 方向键微调，带安全限幅。 */
    private void handleTrims() {
        Gamepad g = mapping.trims;
        if (g.dpadUpWasPressed())    distanceCorrection += 1.0;
        if (g.dpadDownWasPressed())  distanceCorrection -= 1.0;
        if (g.dpadLeftWasPressed())  yawCorrection      += 1.0;
        if (g.dpadRightWasPressed()) yawCorrection      -= 1.0;

        distanceCorrection = Range.clip(distanceCorrection,
                -MAX_DISTANCE_CORRECTION_IN, MAX_DISTANCE_CORRECTION_IN);
        yawCorrection = Range.clip(yawCorrection,
                -MAX_YAW_CORRECTION_DEG, MAX_YAW_CORRECTION_DEG);
    }

    /**
     * 一键自动跑打宏。
     * <ul>
     *   <li>按住 {@code mapping.autoShoot} 对应的键(X) → 第一次按下时：强制打开总开关
     *       (让飞轮提前在开去目标点的路上就开始加速)，同时让 Pedro Pathing 接管底盘，
     *       开始往 {@link #getAutoShootPose()} 走</li>
     *   <li>期间只要摇杆推动幅度超过 {@code MACRO_INTERRUPT_STICK_THRESHOLD} → 立刻打断，
     *       交还完整控制权给操作手（底盘 + 是否继续开火都不再自动进行）</li>
     *   <li>正常松开按键(没有被摇杆打断) → 交还操作杆控制底盘，同时触发一次
     *       {@code firePending}，让 {@link #handleIntake()} 强制喂球
     *       {@code AUTO_SHOOT_FEED_MS} 毫秒，模拟"松开=开火"</li>
     * </ul>
     */
    private void handleAutoShootMacro(double rx, double ry, double hdgDeg) {
        Gamepad g = mapping.autoShoot;
        boolean stickMoved = Math.hypot(mapping.chassis.left_stick_x, mapping.chassis.left_stick_y)
                        > MACRO_INTERRUPT_STICK_THRESHOLD
                || Math.abs(mapping.chassis.right_stick_x) > MACRO_INTERRUPT_STICK_THRESHOLD;

        if (g.x && !macroActive) {
            // ---- 刚按下：启动宏 ----
            macroActive = true;
            shooterOn = true; // 提前开飞轮，趁开过去的路上让它转起来

            Pose start = new Pose(rx, ry, Math.toRadians(hdgDeg));
            Pose target = getAutoShootPose();
            PathBuilder builder = new PathBuilder(followerSub.follower);
            builder.addPath(new BezierLine(
                            new Pose(start.getX(), start.getY()),
                            new Pose(target.getX(), target.getY())))
                    .setLinearHeadingInterpolation(start.getHeading(), target.getHeading());
            followerSub.followPath(builder.build(), true);
        }

        if (!macroActive) {
            return;
        }

        if (stickMoved) {
            // 操作手抢方向盘，立刻打断，完全交还控制权
            followerSub.breakFollowing();
            macroActive = false;
            return;
        }

        if (!g.x) {
            // 正常松开：交还底盘控制权，触发一次自动开火
            followerSub.breakFollowing();
            macroActive = false;
            firePending = true;
            fireTimer.reset();
            return;
        }

        // 按住期间持续驱动Pedro Follower
        followerSub.follower.update();
    }

    // ========================================================================
    // 遥测
    // ========================================================================

    private void updateTelemetry(double rx, double ry, double hdg,
                                  double vx, double vy, double omg,
                                  AutoAimSubsystem_MK2.TurretCommand cmd, double loopMs) {
        joinedTele.addData("alliance", getAllianceName());
        joinedTele.addData("loopMs", loopMs);
        joinedTele.addData("x", rx);
        joinedTele.addData("y", ry);
        joinedTele.addData("h", hdg);
        joinedTele.addData("targetX", getTargetX());
        joinedTele.addData("targetY", getTargetY());
        joinedTele.addData("vx", vx);
        joinedTele.addData("vy", vy);
        joinedTele.addData("omegaDeg", omg);
        joinedTele.addData("shooterOn", shooterOn);
        joinedTele.addData("shootOnTheMove", shootOnTheMove);
        joinedTele.addData("macroActive(自动跑打中)", macroActive);
        joinedTele.addData("firePending(自动开火中)", firePending);
        joinedTele.addData("manualDistanceMode", manualDistanceMode);
        joinedTele.addData("autoAimHasTarget", cmd.hasTarget);
        joinedTele.addData("aimLocked", cmd.isAimLocked);
        joinedTele.addData("targetDist", cmd.targetDist);
        joinedTele.addData("flightTime", cmd.flightTime);
        joinedTele.addData("targetTurretAngle", cmd.targetTurretAngle);
        joinedTele.addData("turretDeg(编码器)", autoAim.getCurrentTurretAngle());
        joinedTele.addData("turretDeg(滤波后)", autoAim.getFilteredTurretAngle());
        joinedTele.addData("aimError", cmd.aimError);
        joinedTele.addData("yawCorrection", yawCorrection);
        joinedTele.addData("distanceCorrection", distanceCorrection);
        joinedTele.addData("targetVelocity(rpm)", targetVelocity);
        joinedTele.addData("shooterVL(实际rpm)", robot.shooter.leftShooter.getVelocity());
        joinedTele.addData("shooterVR(实际rpm)", robot.shooter.rightShooter.getVelocity());
        joinedTele.addData("targetPitch(浮板角度)", cmd.targetPitch);
        joinedTele.addData("intakePower", robot.shooter.calculateIntakePower());
        joinedTele.addData("battery(V)", autoAim.getCurrentBatteryVoltage());
        joinedTele.update();
    }

    // ========================================================================
    // 校验
    // ========================================================================

    /** 确保所有手柄映射已赋值，避免 NPE。 */
    private void validateMapping() {
        if (mapping.chassis    == null) mapping.chassis    = gamepad1;
        if (mapping.actions    == null) mapping.actions    = gamepad1;
        if (mapping.toggles    == null) mapping.toggles    = gamepad1;
        if (mapping.trims      == null) mapping.trims      = gamepad1;
        if (mapping.relocalize == null) mapping.relocalize = gamepad1;
        if (mapping.autoShoot  == null) mapping.autoShoot  = gamepad1;
    }
}
