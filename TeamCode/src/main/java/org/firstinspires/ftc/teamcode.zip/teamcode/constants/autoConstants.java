package org.firstinspires.ftc.teamcode.constants;

import com.pedropathing.geometry.Pose;

public class autoConstants {
    public static long TOTAL_SHOOT_TIME = 0;

    public static long AUTO_CLOSE_WAIT_FOR_SHOOT = 0;
    public static double CLOSE_FIRE_DISTANCE = 75.0;
    public static double CLOSE_FIRE_INTAKE_POWER = 0.8;
    public static double FAR_FIRE_INTAKE_POWER = 0.5;
    public static double CLOSE_HOLD_DISTANCE = CLOSE_FIRE_DISTANCE;
    public static long AUTO_FAR_WAIT_FOR_SHOOT = 800;
    public static double FAR_FIRE_DISTANCE_PRELOAD = 134.4;
    public static double FAR_HOLD_DISTANCE = 123;

    // ==================== BLUE ====================

    public static double BLUE_CLOSE_FIRE_TURRET = -45;

    public static double BLUE_INTAKE_START_X = 45;
    public static double BLUE_INTAKE_END_X = 18.8;
    public static double BLUE_INTAKE_FIRST_ROW_Y = 85.9;
    public static double BLUE_INTAKE_SECOND_ROW_Y = 55;
    public static double BLUE_INTAKE_THIRD_ROW_Y = 36;

    public static Pose BLUE_CLOSE_START = new Pose(23.52, 121.38, Math.toRadians(141.67));
    public static Pose BLUE_CLOSE_SHOOT = new Pose(61.06, 85.1, Math.toRadians(180));
    public static Pose BLUE_CLOSE_SHOOT_CONTROL = new Pose(47.95, 60);
    public static Pose BLUE_CLOSE_SHOOT_PRELOAD = new Pose(BLUE_CLOSE_SHOOT.getX(), BLUE_CLOSE_SHOOT.getY(), BLUE_CLOSE_SHOOT.getHeading());
    public static Pose BLUE_CLOSE_INTAKE_FIRST_CONTROL = new Pose(50, 78);
    public static Pose BLUE_CLOSE_INTAKE_FIRST_END = new Pose(BLUE_INTAKE_END_X - 3, BLUE_INTAKE_FIRST_ROW_Y, Math.toRadians(180));
    public static Pose BLUE_CLOSE_SHOOT_FIRST_ROW = new Pose(59.5, 106, Math.toRadians(150));
    public static Pose BLUE_CLOSE_INTAKE_SECOND_CONTROL = new Pose(47.95, 55);
    public static Pose BLUE_CLOSE_INTAKE_SECOND_END = new Pose(BLUE_INTAKE_END_X - 3, BLUE_INTAKE_SECOND_ROW_Y, Math.toRadians(180));
    public static Pose BLUE_CLOSE_SHOOT_SECOND_ROW = new Pose(BLUE_CLOSE_SHOOT.getX(), BLUE_CLOSE_SHOOT.getY(), BLUE_CLOSE_SHOOT.getHeading());
    public static Pose BLUE_CLOSE_INTAKE_THIRD_START = new Pose(BLUE_INTAKE_START_X, BLUE_INTAKE_THIRD_ROW_Y, Math.toRadians(180));
    public static Pose BLUE_CLOSE_INTAKE_THIRD_END = new Pose(BLUE_INTAKE_END_X, BLUE_INTAKE_THIRD_ROW_Y, Math.toRadians(180));
    public static Pose BLUE_CLOSE_SHOOT_THIRD_ROW = new Pose(BLUE_CLOSE_SHOOT.getX(), BLUE_CLOSE_SHOOT.getY(), BLUE_CLOSE_SHOOT.getHeading());
    public static Pose BLUE_CLOSE_INTAKE_GATE = new Pose(13.27, 59.46, Math.toRadians(155.5));
    public static Pose BLUE_CLOSE_INTAKE_GATE_CONTROL = new Pose(45.5, 63.5);
    public static Pose BLUE_CLOSE_INTAKE_GATE_END = new Pose(15.27, 55.46, Math.toRadians(150.5));
    public static Pose BLUE_CLOSE_SHOOT_INTAKE_GATE = new Pose(BLUE_CLOSE_SHOOT.getX(), BLUE_CLOSE_SHOOT.getY(), BLUE_CLOSE_SHOOT.getHeading());
    public static Pose BLUE_CLOSE_PARK = new Pose(55, 65, Math.toRadians(180));

    public static double BLUE_FAR_TURRET = -69;
    public static Pose BLUE_FAR_START = new Pose(59.72, 12.4, Math.toRadians(180.0));
    public static Pose BLUE_FAR_SHOOT = new Pose(BLUE_FAR_START.getX(), BLUE_FAR_START.getY() + 1, BLUE_FAR_START.getHeading());
    public static Pose BLUE_FAR_INTAKE_HP_1_START = new Pose(13, 13, Math.toRadians(180.0));
    public static Pose BLUE_FAR_INTAKE_HP_1_MID = new Pose(12, 25, Math.toRadians(131));
    public static Pose BLUE_FAR_INTAKE_HP_1_END = new Pose(11, 36, Math.toRadians(120));
    public static Pose BLUE_FAR_SHOOT_HP = new Pose(BLUE_FAR_SHOOT.getX(), BLUE_FAR_SHOOT.getY(), BLUE_FAR_SHOOT.getHeading());
    public static Pose BLUE_FAR_SHOOT_TUNNEL = new Pose(BLUE_FAR_SHOOT.getX(), BLUE_FAR_SHOOT.getY(), BLUE_FAR_SHOOT.getHeading());
    public static Pose BLUE_FAR_PARK = new Pose(37.8, 16.8, Math.toRadians(180.0));
    public static Pose BLUE_FAR_INTAKE_THIRD_CONTROL = new Pose(46.5, 39.7);
    public static Pose BLUE_FAR_INTAKE_THIRD_END = new Pose(14.4, 39, Math.toRadians(180.0));
    public static Pose BLUE_FAR_INTAKE_TUNNEL_START = new Pose(54.0, 26.5, Math.toRadians(180.0));
    public static Pose BLUE_FAR_INTAKE_TUNNEL_END = new Pose(12.0, 26.5, Math.toRadians(165.0));

    // ==================== RED ====================

    public static double RED_CLOSE_FIRE_TURRET = -BLUE_CLOSE_FIRE_TURRET;

    public static double RED_INTAKE_START_X = 144 - BLUE_INTAKE_START_X;
    public static double RED_INTAKE_END_X = 144 - BLUE_INTAKE_END_X;
    public static double RED_INTAKE_FIRST_ROW_Y = BLUE_INTAKE_FIRST_ROW_Y;
    public static double RED_INTAKE_SECOND_ROW_Y = BLUE_INTAKE_SECOND_ROW_Y;
    public static double RED_INTAKE_THIRD_ROW_Y = BLUE_INTAKE_THIRD_ROW_Y;

    public static Pose RED_CLOSE_START = new Pose(144 - BLUE_CLOSE_START.getX(), BLUE_CLOSE_START.getY(), Math.toRadians(180) - BLUE_CLOSE_START.getHeading());
    public static Pose RED_CLOSE_SHOOT = new Pose(144 - BLUE_CLOSE_SHOOT.getX(), BLUE_CLOSE_SHOOT.getY(), Math.toRadians(180) - BLUE_CLOSE_SHOOT.getHeading());
    public static Pose RED_CLOSE_SHOOT_CONTROL = new Pose(144 - BLUE_CLOSE_SHOOT_CONTROL.getX(), BLUE_CLOSE_SHOOT_CONTROL.getY());
    public static Pose RED_CLOSE_SHOOT_PRELOAD = new Pose(RED_CLOSE_SHOOT.getX(), RED_CLOSE_SHOOT.getY(), RED_CLOSE_SHOOT.getHeading());
    public static Pose RED_CLOSE_INTAKE_FIRST_CONTROL = new Pose(144 - BLUE_CLOSE_INTAKE_FIRST_CONTROL.getX(), BLUE_CLOSE_INTAKE_FIRST_CONTROL.getY());
    public static Pose RED_CLOSE_INTAKE_FIRST_END = new Pose(144 - BLUE_CLOSE_INTAKE_FIRST_END.getX(), BLUE_CLOSE_INTAKE_FIRST_END.getY(), Math.toRadians(180) - BLUE_CLOSE_INTAKE_FIRST_END.getHeading());
    public static Pose RED_CLOSE_SHOOT_FIRST_ROW = new Pose(144 - BLUE_CLOSE_SHOOT_FIRST_ROW.getX(), BLUE_CLOSE_SHOOT_FIRST_ROW.getY(), Math.toRadians(180) - BLUE_CLOSE_SHOOT_FIRST_ROW.getHeading());
    public static Pose RED_CLOSE_INTAKE_SECOND_CONTROL = new Pose(144 - BLUE_CLOSE_INTAKE_SECOND_CONTROL.getX(), BLUE_CLOSE_INTAKE_SECOND_CONTROL.getY());
    public static Pose RED_CLOSE_INTAKE_SECOND_END = new Pose(144 - BLUE_CLOSE_INTAKE_SECOND_END.getX(), BLUE_CLOSE_INTAKE_SECOND_END.getY(), Math.toRadians(180) - BLUE_CLOSE_INTAKE_SECOND_END.getHeading());
    public static Pose RED_CLOSE_SHOOT_SECOND_ROW = new Pose(RED_CLOSE_SHOOT.getX(), RED_CLOSE_SHOOT.getY(), RED_CLOSE_SHOOT.getHeading());
    public static Pose RED_CLOSE_INTAKE_THIRD_START = new Pose(RED_INTAKE_START_X, RED_INTAKE_THIRD_ROW_Y, Math.toRadians(180) - BLUE_CLOSE_INTAKE_THIRD_START.getHeading());
    public static Pose RED_CLOSE_INTAKE_THIRD_END = new Pose(RED_INTAKE_END_X, RED_INTAKE_THIRD_ROW_Y, Math.toRadians(180) - BLUE_CLOSE_INTAKE_THIRD_END.getHeading());
    public static Pose RED_CLOSE_SHOOT_THIRD_ROW = new Pose(RED_CLOSE_SHOOT.getX(), RED_CLOSE_SHOOT.getY(), RED_CLOSE_SHOOT.getHeading());
    public static Pose RED_CLOSE_INTAKE_GATE = new Pose(144 - BLUE_CLOSE_INTAKE_GATE.getX(), BLUE_CLOSE_INTAKE_GATE.getY(), Math.toRadians(180) - BLUE_CLOSE_INTAKE_GATE.getHeading());
    public static Pose RED_CLOSE_INTAKE_GATE_CONTROL = new Pose(144 - BLUE_CLOSE_INTAKE_GATE_CONTROL.getX(), BLUE_CLOSE_INTAKE_GATE_CONTROL.getY());
    public static Pose RED_CLOSE_INTAKE_GATE_END = new Pose(144 - BLUE_CLOSE_INTAKE_GATE_END.getX(), BLUE_CLOSE_INTAKE_GATE_END.getY(), Math.toRadians(180) - BLUE_CLOSE_INTAKE_GATE_END.getHeading());
    public static Pose RED_CLOSE_SHOOT_INTAKE_GATE = new Pose(RED_CLOSE_SHOOT.getX(), RED_CLOSE_SHOOT.getY(), RED_CLOSE_SHOOT.getHeading());
    public static Pose RED_CLOSE_PARK = new Pose(144 - BLUE_CLOSE_PARK.getX(), BLUE_CLOSE_PARK.getY(), Math.toRadians(180) - BLUE_CLOSE_PARK.getHeading());

    public static double RED_FAR_TURRET = -BLUE_FAR_TURRET;
    public static Pose RED_FAR_START = new Pose(144 - BLUE_FAR_START.getX(), BLUE_FAR_START.getY(), Math.toRadians(180) - BLUE_FAR_START.getHeading());
    public static Pose RED_FAR_SHOOT = new Pose(RED_FAR_START.getX(), RED_FAR_START.getY() + 1, RED_FAR_START.getHeading());
    public static Pose RED_FAR_INTAKE_HP_1_START = new Pose(144 - BLUE_FAR_INTAKE_HP_1_START.getX(), BLUE_FAR_INTAKE_HP_1_START.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_HP_1_START.getHeading());
    public static Pose RED_FAR_INTAKE_HP_1_MID = new Pose(144 - BLUE_FAR_INTAKE_HP_1_MID.getX(), BLUE_FAR_INTAKE_HP_1_MID.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_HP_1_MID.getHeading());
    public static Pose RED_FAR_INTAKE_HP_1_END = new Pose(144 - BLUE_FAR_INTAKE_HP_1_END.getX(), BLUE_FAR_INTAKE_HP_1_END.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_HP_1_END.getHeading());
    public static Pose RED_FAR_SHOOT_HP = new Pose(RED_FAR_SHOOT.getX(), RED_FAR_SHOOT.getY(), RED_FAR_SHOOT.getHeading());
    public static Pose RED_FAR_SHOOT_TUNNEL = new Pose(RED_FAR_SHOOT.getX(), RED_FAR_SHOOT.getY(), RED_FAR_SHOOT.getHeading());
    public static Pose RED_FAR_PARK = new Pose(144 - BLUE_FAR_PARK.getX(), BLUE_FAR_PARK.getY(), Math.toRadians(180) - BLUE_FAR_PARK.getHeading());
    public static Pose RED_FAR_INTAKE_THIRD_CONTROL = new Pose(144 - BLUE_FAR_INTAKE_THIRD_CONTROL.getX(), BLUE_FAR_INTAKE_THIRD_CONTROL.getY());
    public static Pose RED_FAR_INTAKE_THIRD_END = new Pose(144 - BLUE_FAR_INTAKE_THIRD_END.getX(), BLUE_FAR_INTAKE_THIRD_END.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_THIRD_END.getHeading());
    public static Pose RED_FAR_INTAKE_TUNNEL_START = new Pose(144 - BLUE_FAR_INTAKE_TUNNEL_START.getX(), BLUE_FAR_INTAKE_TUNNEL_START.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_TUNNEL_START.getHeading());
    public static Pose RED_FAR_INTAKE_TUNNEL_END = new Pose(144 - BLUE_FAR_INTAKE_TUNNEL_END.getX(), BLUE_FAR_INTAKE_TUNNEL_END.getY(), Math.toRadians(180) - BLUE_FAR_INTAKE_TUNNEL_END.getHeading());
}